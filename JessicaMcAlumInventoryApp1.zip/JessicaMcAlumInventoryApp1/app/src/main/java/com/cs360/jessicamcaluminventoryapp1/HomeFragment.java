package com.cs360.jessicamcaluminventoryapp1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;

    private InventoryAdapter adapter;

    private ItemViewModel itemViewModel;

public HomeFragment() {

}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize the ItemViewModel
        itemViewModel = new ViewModelProvider(requireActivity()).get(ItemViewModel.class);

        // Initialize RecyclerView and adapter
        recyclerView = view.findViewById(R.id.recycler_inventory);
        adapter = new InventoryAdapter(new ArrayList<>());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);

        // "Add" button click listener
        Button addButton = view.findViewById(R.id.buttonAddItem);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddItemDialog();
            }
        });

        // Updates the adapter from the ViewModel item list
        itemViewModel.getItemList().observe(getViewLifecycleOwner(), items -> {
            adapter.setItems(items);
        });
        return view;
    }

    // Method for the dialog for adding an item
    private void showAddItemDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Add Item");

        View dialogView = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        final EditText itemNameEditText = dialogView.findViewById(R.id.editTextItemName);
        final EditText itemQuantityEditText = dialogView.findViewById(R.id.editTextItemQuantity);

        // Positive button click listener
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String itemName = itemNameEditText.getText().toString();
                int itemQuantity = Integer.parseInt(itemQuantityEditText.getText().toString());

                    // Creates new item and adds it to the ViewModel
                    Item newItem = new Item(itemName, itemQuantity);
                    itemViewModel.addItem(newItem);

                        // Notifies user that item was added successfully
                        Toast.makeText(requireContext(), "Item added successfully", Toast.LENGTH_SHORT).show();
                }
        });

        // Sets cancel button
        builder.setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Method for the dialog for editing an item
    private void showEditItemDialog(final Item itemToEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_edit_item, null);
        builder.setView(dialogView);

        final TextView itemNameTextView = dialogView.findViewById(R.id.textViewName);
        final EditText itemQuantityEditText = dialogView.findViewById(R.id.editTextQuantity);
        Button buttonEdit = dialogView.findViewById(R.id.buttonUpdate);

        itemNameTextView.setText(itemToEdit.getName());
        itemQuantityEditText.setText(String.valueOf(itemToEdit.getQuantity()));

        builder.setTitle("Edit Item");
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();

        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String quantityString = itemQuantityEditText.getText().toString().trim();

                if (quantityString.isEmpty()) {
                    Toast.makeText(requireContext(), "Please enter quantity", Toast.LENGTH_SHORT).show();
                    return;
                }

                int quantity = Integer.parseInt(quantityString);

                itemToEdit.setQuantity(quantity);
                itemViewModel.updateItem(itemToEdit);

                alertDialog.dismiss();
                Toast.makeText(requireContext(), "Item updated successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method for the dialog for deleting an item
    private void showDeleteItemDialog(final Item itemToDelete) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Confirm Deletion");
        builder.setMessage("Are you sure you want to delete this item?");

        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                itemViewModel.deleteItem(itemToDelete);

                Toast.makeText(requireContext(), "Item deleted successfully", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
        private List<Item> itemList;
        public InventoryAdapter(List<Item> itemList) {
            this.itemList = itemList;
        }

        // Sets items in adapter
        public void setItems(List<Item> items) {
            itemList = items;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_items, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Item item = itemList.get(position);

            // Sets name and quantity for each item
            holder.itemNameTextView.setText(item.getName());
            holder.itemQuantityTextView.setText(String.valueOf(item.getQuantity()));

            // Click listener for edit button
            holder.editButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    showEditItemDialog(item);
                }
            });

            // Click listener for delete button
            holder.deleteButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    showDeleteItemDialog(item);
                }
            });
        }

        // Returns number of items in the list
        @Override
        public int getItemCount(){
            return itemList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView itemNameTextView;
            TextView itemQuantityTextView;
            Button deleteButton;
            Button editButton;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                itemNameTextView = itemView.findViewById(R.id.itemNameText);
                itemQuantityTextView = itemView.findViewById(R.id.itemQuantityText);
                editButton = itemView.findViewById(R.id.buttonEdit);
                deleteButton = itemView.findViewById(R.id.buttonDeleteItem);
            }
        }
    }
}