package com.cs360.jessicamcaluminventoryapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.MenuItem;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class InventoryActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    HomeFragment homeFragment = new HomeFragment();
    OutOfStockFragment outOfStockFragment = new OutOfStockFragment();
    SettingsFragment settingsFragment = new SettingsFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Sets the screen to the HomeFragment screen
        getSupportFragmentManager().beginTransaction().replace(R.id.container,homeFragment).commit();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {

            // Switches screens from bottom navigation menu bar
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                if (item.getItemId() == R.id.menu_home) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,homeFragment).commit();
                    return true;
                }
                else if (item.getItemId() == R.id.menu_out_of_stock){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,outOfStockFragment).commit();
                    return true;
                }
                else if (item.getItemId() == R.id.menu_settings){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,settingsFragment).commit();
                    return true;
                }

                return false;
            }
        });
    }
}