package com.cs360.jessicamcaluminventoryapp1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class OutOfStockFragment extends Fragment {

    private RecyclerView recyclerView;
    private OutOfStockAdapter adapter;
    private ItemViewModel itemViewModel;
    public OutOfStockFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        itemViewModel = new ViewModelProvider(requireActivity()).get(ItemViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_out_of_stock, container, false);
        recyclerView = view.findViewById(R.id.recycler_out_of_stock);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new OutOfStockAdapter();
        recyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onResume(){
        super.onResume();
        loadOutOfStockItems();
    }

    // Retrieves out-of-stock items from ItemViewModel
    void loadOutOfStockItems(){
        List<Item> itemList = itemViewModel.getItemList().getValue();
        if(itemList != null) {
            List<Item> outOfStockItems = new ArrayList<> ();
            for (Item item : itemList) {
                if (item.getQuantity() == 0) {
                    outOfStockItems.add(item);
                }
            }
            adapter.setItems(outOfStockItems);
            adapter.notifyDataSetChanged();
        }
    }

    // Method for the dialog for editing an item
    private void showEditItemDialog(final Item itemToEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_edit_item, null);
        builder.setView(dialogView);

        final TextView itemNameText = dialogView.findViewById(R.id.textViewName);
        final EditText itemQuantityEditText = dialogView.findViewById(R.id.editTextQuantity);
        Button buttonEdit = dialogView.findViewById(R.id.buttonUpdate);

        itemNameText.setText(itemToEdit.getName());
        itemQuantityEditText.setText(String.valueOf(itemToEdit.getQuantity()));

        builder.setTitle("Edit Item");
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();

        // Adds updated item to the database
        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String quantityString = itemQuantityEditText.getText().toString().trim();

                if (quantityString.isEmpty()) {
                    Toast.makeText(requireContext(), "Please enter name and quantity", Toast.LENGTH_SHORT).show();
                    return;
                }

                int quantity = Integer.parseInt(quantityString);

                itemToEdit.setQuantity(quantity);

                itemViewModel.updateItem(itemToEdit);

                alertDialog.dismiss();
                Toast.makeText(requireContext(), "Item updated successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDeleteItemDialog(final Item itemToDelete) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Confirm Deletion");
        builder.setMessage("Are you sure you want to delete this item?");

        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                itemViewModel.deleteItem(itemToDelete);

                Toast.makeText(requireContext(), "Item deleted successfully", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private class OutOfStockAdapter extends RecyclerView.Adapter<OutOfStockAdapter.ViewHolder> {
        private List<Item> outOfStockItems;
        public void setItems(List<Item> outOfStockItems) {
            this.outOfStockItems = outOfStockItems;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_out_of_stock, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Item item = outOfStockItems.get(position);
            holder.itemNameTextView.setText(item.getName());
            holder.itemQuantityTextView.setText(String.valueOf(item.getQuantity()));

            holder.editButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    showEditItemDialog(item);
                }
            });

            holder.deleteButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    showDeleteItemDialog(item);
                }
            });
        }

        @Override
        public int getItemCount() {
            return outOfStockItems != null ? outOfStockItems.size() : 0;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView itemNameTextView;
            TextView itemQuantityTextView;
            Button deleteButton;
            Button editButton;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                itemNameTextView = itemView.findViewById(R.id.itemNameText);
                itemQuantityTextView = itemView.findViewById(R.id.itemQuantityText);
                deleteButton = itemView.findViewById(R.id.buttonDeleteItem);
                editButton = itemView.findViewById(R.id.buttonEdit);
            }
        }
    }
}