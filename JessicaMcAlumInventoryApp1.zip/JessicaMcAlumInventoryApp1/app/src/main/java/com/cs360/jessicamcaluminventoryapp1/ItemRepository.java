package com.cs360.jessicamcaluminventoryapp1;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;
public class ItemRepository {
    private ItemDatabaseHelper databaseHelper;
    private MutableLiveData<List<Item>> allItems;

    public ItemRepository(Application application) {

        databaseHelper = new ItemDatabaseHelper(application);
        allItems = new MutableLiveData<>(databaseHelper.getAllItems());
    }

    public LiveData<List<Item>> getItemList() {
        return allItems;
    }

    public void addItem(Item item) {
        databaseHelper.addItem(item);
        allItems.setValue(databaseHelper.getAllItems());
    }

    public void updateItem(Item item) {
        databaseHelper.updateItem(item);
        allItems.setValue(databaseHelper.getAllItems());
    }
    public void deleteItem(Item item) {
        databaseHelper.deleteItem(item);
        allItems.setValue(databaseHelper.getAllItems());
    }
}
