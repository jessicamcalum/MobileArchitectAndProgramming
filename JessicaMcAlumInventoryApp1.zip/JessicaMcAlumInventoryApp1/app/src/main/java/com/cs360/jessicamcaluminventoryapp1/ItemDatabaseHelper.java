package com.cs360.jessicamcaluminventoryapp1;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ItemDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "InventoryItems.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_ITEMS = "items";
    private static final String COLUMN_ITEM_NAME = "name";
    private static final String COLUMN_ITEM_QUANTITY = "quantity";

    public ItemDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Database table to store inventory items
        String createTableQuery = "CREATE TABLE " + TABLE_ITEMS + "("
                + COLUMN_ITEM_NAME + " TEXT, "
                + COLUMN_ITEM_QUANTITY + " INTEGER"
                + ")";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // Adds item to the database
    public long addItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();

        // Checks for duplicate item names
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ITEMS + " WHERE " + COLUMN_ITEM_NAME + " = ?", new String[]{item.getName()});
        if (cursor.getCount() > 0) {
            cursor.close();
            db.close();
            return -1; // Item already exists
        }
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_ITEM_QUANTITY, item.getQuantity());
        long result = db.insertWithOnConflict(TABLE_ITEMS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
        return result;
    }

    // Edits an item in the database
    public void updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_ITEM_QUANTITY, item.getQuantity());
        db.update(TABLE_ITEMS, values, COLUMN_ITEM_NAME + " = ?", new String[]{String.valueOf(item.getName())});
        db.close();
    }

    // Deletes an item in the database
    public void deleteItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ITEMS, COLUMN_ITEM_NAME + " = ?", new String[]{String.valueOf(item.getName())});
        db.close();
    }

    // Gets all items from the database
    public List<Item> getAllItems(){
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ITEMS, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_NAME));
                @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex(COLUMN_ITEM_QUANTITY));
                Item item = new Item(name, quantity);
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemList;
    }

    // Gets all out of stock items from the database
    public List<Item> getOutOfStockItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Item> outOfStockItems = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_ITEMS + " WHERE " + COLUMN_ITEM_QUANTITY + " = 0";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_NAME));
                @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex(COLUMN_ITEM_QUANTITY));
                Item item = new Item(name, quantity);
                outOfStockItems.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return outOfStockItems;
    }
}
