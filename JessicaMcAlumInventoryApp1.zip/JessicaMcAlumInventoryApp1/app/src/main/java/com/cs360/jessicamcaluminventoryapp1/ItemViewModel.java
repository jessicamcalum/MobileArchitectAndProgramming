package com.cs360.jessicamcaluminventoryapp1;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ItemViewModel extends AndroidViewModel {
    private ItemRepository itemRepository;
    private LiveData<List<Item>> allItems;

    public ItemViewModel(@NonNull Application application) {
        super(application);
        itemRepository = new ItemRepository(application);
        allItems = itemRepository.getItemList();
    }

    public LiveData<List<Item>> getItemList() {
        return allItems;
    }

    public void addItem(Item item) {
        itemRepository.addItem(item);
        allItems = itemRepository.getItemList();
    }
    public void updateItem(Item item) {
        itemRepository.updateItem(item);
        allItems = itemRepository.getItemList();
    }
    public void deleteItem(Item item) {
        itemRepository.deleteItem(item);
        allItems = itemRepository.getItemList();
    }
}

