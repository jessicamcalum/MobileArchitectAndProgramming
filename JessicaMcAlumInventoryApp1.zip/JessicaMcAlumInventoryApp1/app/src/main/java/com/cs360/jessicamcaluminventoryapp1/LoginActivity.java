package com.cs360.jessicamcaluminventoryapp1;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class LoginActivity extends AppCompatActivity{
   private EditText usernameText;
   private EditText userPasswordText;
   private SQLiteOpenHelper dbHelper;
   private SQLiteDatabase database;

   @Override
   protected void onCreate(Bundle savedInstanceState){
       super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_login);

       dbHelper = new UserDatabaseHelper(this);

       // Username and password fields
       usernameText = findViewById(R.id.usernameText);
       userPasswordText = findViewById(R.id.userPasswordText);

       // Login button
       Button buttonLogin =findViewById(R.id.buttonLogin);
       buttonLogin.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               login();
           }
       });

       Button buttonCreateLogin = findViewById(R.id.buttonCreateLogin);
       buttonCreateLogin.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               createAccount();
           }
       });
   }

   private void login() {
       // Gets username and password
       String username = usernameText.getText().toString();
       String password = userPasswordText.getText().toString();

       // Checks for user in database
       User user = getUserFromDatabase(username);

       if (user != null && user.getPassword().equals(password)) {

           Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
           // Displays Home screen if login is successful
           navigateToHomeFragment();
       }
       else {
           Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
       }
   }

   // Method to navigate to the Home screen
   private void navigateToHomeFragment() {
       Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
       startActivity(intent);
       finish();
   }

   // Creates a new user account using the username and password entered
   private void createAccount(){
       String username = usernameText.getText().toString();
       String password = userPasswordText.getText().toString();

       if (getUserFromDatabase(username) != null) {
           Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
           return;
       }

       addUserToDatabase(username, password);

       Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
   }

    // User verification
   private User getUserFromDatabase(String username) {
       database = dbHelper.getReadableDatabase();

       Cursor cursor = database.query(
               "users",
               new String[]{"username", "password"},
               "username = ?",
               new String[]{username},
               null, null, null
       );

       User user = null;
       if (cursor != null && cursor.moveToFirst()) {
           @SuppressLint("Range") String storedUsername = cursor.getString(cursor.getColumnIndex("username"));
           @SuppressLint("Range") String storedPassword = cursor.getString(cursor.getColumnIndex("password"));
           user = new User(storedUsername, storedPassword);
           cursor.close();
       }

       database.close();
       return user;
   }

   // Adds user to the database
   private void addUserToDatabase(String username, String password) {
       database = dbHelper.getWritableDatabase();

       ContentValues values = new ContentValues();
       values.put("username", username);
       values.put("password", password);

       database.insert("users", null, values);
       database.close();

   }
}