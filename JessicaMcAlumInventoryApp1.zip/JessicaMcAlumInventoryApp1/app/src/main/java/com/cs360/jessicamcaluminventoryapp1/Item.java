package com.cs360.jessicamcaluminventoryapp1;

public class Item {
    private String itemNameText;
    private int itemQuantityText;

    public Item(String itemNameText, int itemQuantityText) {
        this.itemNameText = itemNameText;
        this.itemQuantityText = itemQuantityText;
    }

    public String getName() {
        return itemNameText;
    }

    public void setName(String itemNameText) {
        this.itemNameText = itemNameText;
    }

    public int getQuantity() {
        return itemQuantityText;
    }

    public void setQuantity(int itemQuantityText) {
        this.itemQuantityText = itemQuantityText;
    }
}
